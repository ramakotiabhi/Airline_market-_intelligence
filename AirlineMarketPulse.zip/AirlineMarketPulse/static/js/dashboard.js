/**
 * Dashboard JavaScript for Australian Airline Market Intelligence
 * Handles dashboard functionality, data loading, and user interactions
 */

// Global variables
let dashboardData = {};
let chartsInstances = {};
let currentFilters = {};
let refreshInterval;

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeDashboard();
    setupEventListeners();
    loadInitialData();
    
    // Setup auto-refresh every 5 minutes
    setupAutoRefresh();
});

/**
 * Initialize dashboard components
 */
function initializeDashboard() {
    console.log('Initializing dashboard...');
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize loading states
    showLoadingStates();
}

/**
 * Setup event listeners for dashboard interactions
 */
function setupEventListeners() {
    // Filter form submission
    const filterForm = document.getElementById('filter-form');
    if (filterForm) {
        filterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            applyFilters();
        });
    }
    
    // Clear filters button
    const clearFiltersBtn = document.getElementById('clear-filters');
    if (clearFiltersBtn) {
        clearFiltersBtn.addEventListener('click', clearFilters);
    }
    
    // Refresh button
    const refreshBtn = document.getElementById('refresh-btn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', refreshDashboard);
    }
    
    // Export button
    const exportBtn = document.getElementById('export-btn');
    if (exportBtn) {
        exportBtn.addEventListener('click', exportData);
    }
    
    // Filter dropdowns
    const filterSelects = document.querySelectorAll('.filter-select');
    filterSelects.forEach(select => {
        select.addEventListener('change', function() {
            if (this.value) {
                applyFilters();
            }
        });
    });
}

/**
 * Load initial dashboard data
 */
function loadInitialData() {
    console.log('Loading initial dashboard data...');
    
    Promise.all([
        loadDashboardStats(),
        loadRouteData(),
        loadPriceTrends(),
        loadHeatmapData()
    ]).then(() => {
        console.log('Initial data loaded successfully');
        hideLoadingStates();
    }).catch(error => {
        console.error('Error loading initial data:', error);
        showError('Failed to load dashboard data. Please try refreshing the page.');
    });
}

/**
 * Load dashboard statistics
 */
async function loadDashboardStats() {
    try {
        const response = await fetch('/dashboard/api/stats');
        const data = await response.json();
        
        if (data.error) {
            throw new Error(data.error);
        }
        
        dashboardData.stats = data;
        updateMetricsCards(data);
        updateFiltersDropdowns(data);
        
        return data;
    } catch (error) {
        console.error('Error loading dashboard stats:', error);
        throw error;
    }
}

/**
 * Load route data for charts
 */
async function loadRouteData() {
    try {
        const response = await fetch('/dashboard/api/route-data');
        const data = await response.json();
        
        if (data.error) {
            throw new Error(data.error);
        }
        
        dashboardData.routes = data;
        updateRoutesTable(data.routes);
        
        return data;
    } catch (error) {
        console.error('Error loading route data:', error);
        throw error;
    }
}

/**
 * Load price trends data
 */
async function loadPriceTrends() {
    try {
        const response = await fetch('/dashboard/api/price-trends');
        const data = await response.json();
        
        if (data.error) {
            throw new Error(data.error);
        }
        
        dashboardData.priceTrends = data;
        
        return data;
    } catch (error) {
        console.error('Error loading price trends:', error);
        throw error;
    }
}

/**
 * Load heatmap data
 */
async function loadHeatmapData() {
    try {
        const response = await fetch('/dashboard/api/heatmap-data');
        const data = await response.json();
        
        if (data.error) {
            throw new Error(data.error);
        }
        
        dashboardData.heatmap = data;
        
        return data;
    } catch (error) {
        console.error('Error loading heatmap data:', error);
        throw error;
    }
}

/**
 * Update metrics cards with new data
 */
function updateMetricsCards(data) {
    const elements = {
        'metric-flights': data.total_flights || 0,
        'metric-routes': data.total_routes || 0,
        'metric-airlines': data.active_airlines || 0,
        'metric-updated': formatLastUpdated(data.last_updated)
    };
    
    Object.entries(elements).forEach(([id, value]) => {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = value;
            
            // Add animation
            element.classList.add('fade-in');
            setTimeout(() => {
                element.classList.remove('fade-in');
            }, 500);
        }
    });
}

/**
 * Update filter dropdowns with available options
 */
function updateFiltersDropdowns(data) {
    // Update airlines dropdown
    const airlineSelect = document.getElementById('filter-airline');
    if (airlineSelect && data.airlines) {
        airlineSelect.innerHTML = '<option value="">All Airlines</option>';
        data.airlines.forEach(airline => {
            const option = document.createElement('option');
            option.value = airline;
            option.textContent = airline;
            airlineSelect.appendChild(option);
        });
    }
    
    // Update origins and destinations dropdowns
    const originSelect = document.getElementById('filter-origin');
    const destinationSelect = document.getElementById('filter-destination');
    
    if (originSelect && destinationSelect && data.popular_destinations) {
        const destinations = data.popular_destinations.map(dest => dest[0]);
        
        [originSelect, destinationSelect].forEach(select => {
            select.innerHTML = '<option value="">All Locations</option>';
            destinations.forEach(dest => {
                const option = document.createElement('option');
                option.value = dest;
                option.textContent = dest;
                select.appendChild(option);
            });
        });
    }
}

/**
 * Update routes table
 */
function updateRoutesTable(routes) {
    const tableBody = document.getElementById('routes-table');
    if (!tableBody) return;
    
    if (!routes || routes.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="4" class="text-center text-muted">No route data available</td></tr>';
        return;
    }
    
    tableBody.innerHTML = routes.slice(0, 10).map(route => `
        <tr>
            <td>
                <strong>${route.route}</strong>
                <br>
                <small class="text-muted">${route.demand_trend || 'stable'} trend</small>
            </td>
            <td>
                <span class="badge bg-primary">${route.frequency}</span>
            </td>
            <td>${route.origin || 'N/A'}</td>
            <td>${route.destination || 'N/A'}</td>
        </tr>
    `).join('');
}

/**
 * Apply filters to dashboard data
 */
async function applyFilters() {
    const filters = {
        airline: document.getElementById('filter-airline')?.value || '',
        origin: document.getElementById('filter-origin')?.value || '',
        destination: document.getElementById('filter-destination')?.value || '',
        date_range: document.getElementById('filter-date-range')?.value || ''
    };
    
    // Build query parameters
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
        if (value) {
            if (key === 'date_range') {
                const endDate = new Date();
                const startDate = new Date();
                startDate.setDate(endDate.getDate() - parseInt(value));
                params.append('start_date', startDate.toISOString());
                params.append('end_date', endDate.toISOString());
            } else {
                params.append(key, value);
            }
        }
    });
    
    try {
        showLoadingStates();
        
        const response = await fetch(`/dashboard/api/filter?${params}`);
        const data = await response.json();
        
        if (data.error) {
            throw new Error(data.error);
        }
        
        // Update dashboard with filtered data
        currentFilters = filters;
        updateMetricsCards(data);
        
        showSuccess('Filters applied successfully');
        
    } catch (error) {
        console.error('Error applying filters:', error);
        showError('Failed to apply filters. Please try again.');
    } finally {
        hideLoadingStates();
    }
}

/**
 * Clear all filters
 */
function clearFilters() {
    // Reset all filter inputs
    const filterInputs = document.querySelectorAll('.filter-select, .filter-input');
    filterInputs.forEach(input => {
        input.value = '';
    });
    
    currentFilters = {};
    
    // Reload original data
    loadInitialData();
    
    showSuccess('Filters cleared');
}

/**
 * Refresh dashboard data
 */
async function refreshDashboard() {
    console.log('Refreshing dashboard...');
    
    try {
        showLoadingStates();
        
        // Force refresh by adding timestamp to prevent caching
        const timestamp = Date.now();
        
        await Promise.all([
            fetch(`/dashboard/api/stats?t=${timestamp}`).then(r => r.json()),
            fetch(`/dashboard/api/route-data?t=${timestamp}`).then(r => r.json()),
            fetch(`/dashboard/api/price-trends?t=${timestamp}`).then(r => r.json()),
            fetch(`/dashboard/api/heatmap-data?t=${timestamp}`).then(r => r.json())
        ]);
        
        await loadInitialData();
        
        showSuccess('Dashboard refreshed successfully');
        
    } catch (error) {
        console.error('Error refreshing dashboard:', error);
        showError('Failed to refresh dashboard. Please try again.');
    } finally {
        hideLoadingStates();
    }
}

/**
 * Export dashboard data
 */
function exportData() {
    const exportUrl = '/api/data/export';
    
    // Create a temporary link to trigger download
    const link = document.createElement('a');
    link.href = exportUrl;
    link.download = `airline_data_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    showSuccess('Data export started');
}

/**
 * Setup auto-refresh functionality
 */
function setupAutoRefresh() {
    // Refresh every 5 minutes
    refreshInterval = setInterval(() => {
        console.log('Auto-refreshing dashboard...');
        loadInitialData();
    }, 5 * 60 * 1000);
    
    // Clear interval when page is unloaded
    window.addEventListener('beforeunload', () => {
        if (refreshInterval) {
            clearInterval(refreshInterval);
        }
    });
}

/**
 * Show loading states
 */
function showLoadingStates() {
    const loadingElements = document.querySelectorAll('.loading-placeholder');
    loadingElements.forEach(element => {
        element.innerHTML = `
            <div class="d-flex align-items-center justify-content-center p-3">
                <div class="spinner-border text-primary me-2" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <span class="text-muted">Loading...</span>
            </div>
        `;
    });
    
    // Show loading cursor
    document.body.style.cursor = 'wait';
}

/**
 * Hide loading states
 */
function hideLoadingStates() {
    document.body.style.cursor = 'default';
    
    const loadingElements = document.querySelectorAll('.loading-placeholder');
    loadingElements.forEach(element => {
        element.innerHTML = '';
    });
}

/**
 * Show success message
 */
function showSuccess(message) {
    console.log('Success:', message);
    
    // Create temporary success alert
    const alert = document.createElement('div');
    alert.className = 'alert alert-success alert-dismissible fade show position-fixed';
    alert.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    alert.innerHTML = `
        <i class="fas fa-check-circle me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alert);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (alert.parentNode) {
            alert.parentNode.removeChild(alert);
        }
    }, 5000);
}

/**
 * Show error message
 */
function showError(message) {
    console.error('Error:', message);
    
    // Create temporary error alert
    const alert = document.createElement('div');
    alert.className = 'alert alert-danger alert-dismissible fade show position-fixed';
    alert.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    alert.innerHTML = `
        <i class="fas fa-exclamation-triangle me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alert);
    
    // Auto-remove after 8 seconds
    setTimeout(() => {
        if (alert.parentNode) {
            alert.parentNode.removeChild(alert);
        }
    }, 8000);
}

/**
 * Format last updated timestamp
 */
function formatLastUpdated(timestamp) {
    if (!timestamp) return 'Never';
    
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    
    // Convert to minutes
    const minutes = Math.floor(diff / 60000);
    
    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes} min ago`;
    
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    
    const days = Math.floor(hours / 24);
    return `${days} day${days > 1 ? 's' : ''} ago`;
}

/**
 * Format numbers for display
 */
function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
}

/**
 * Format currency
 */
function formatCurrency(amount, currency = 'AUD') {
    if (amount === null || amount === undefined) return 'N/A';
    
    return new Intl.NumberFormat('en-AU', {
        style: 'currency',
        currency: currency
    }).format(amount);
}

/**
 * Debounce function to limit API calls
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Throttle function to limit API calls
 */
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Export functions for use in other files
window.DashboardJS = {
    loadDashboardStats,
    loadRouteData,
    loadPriceTrends,
    loadHeatmapData,
    applyFilters,
    clearFilters,
    refreshDashboard,
    exportData,
    showSuccess,
    showError,
    formatNumber,
    formatCurrency,
    debounce,
    throttle
};
