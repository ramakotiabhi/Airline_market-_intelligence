/**
 * Charts JavaScript for Australian Airline Market Intelligence
 * Handles all chart creation and management using Chart.js and Plotly.js
 */

// Chart instances storage
let chartInstances = {};

// Chart color schemes
const colorSchemes = {
    primary: ['#007bff', '#6610f2', '#6f42c1', '#e83e8c', '#dc3545', '#fd7e14', '#ffc107', '#28a745', '#20c997', '#17a2b8'],
    airlines: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40', '#FF6384', '#C9CBCF', '#4BC0C0', '#36A2EB'],
    gradient: {
        primary: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        secondary: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
        success: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
        warning: 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)'
    }
};

// Chart default options
const defaultOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
        legend: {
            position: 'top',
            labels: {
                usePointStyle: true,
                padding: 20
            }
        },
        tooltip: {
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            titleColor: '#fff',
            bodyColor: '#fff',
            borderColor: '#007bff',
            borderWidth: 1,
            cornerRadius: 6,
            displayColors: true
        }
    },
    scales: {
        y: {
            beginAtZero: true,
            grid: {
                color: 'rgba(0, 0, 0, 0.1)'
            },
            ticks: {
                color: '#666'
            }
        },
        x: {
            grid: {
                color: 'rgba(0, 0, 0, 0.1)'
            },
            ticks: {
                color: '#666'
            }
        }
    }
};

/**
 * Create routes chart (bar chart)
 */
function createRoutesChart(routeData) {
    const ctx = document.getElementById('routesChart');
    if (!ctx) return;
    
    // Destroy existing chart
    if (chartInstances.routesChart) {
        chartInstances.routesChart.destroy();
    }
    
    if (!routeData || routeData.length === 0) {
        showEmptyChart(ctx, 'No route data available');
        return;
    }
    
    // Prepare data for top 10 routes
    const topRoutes = routeData.slice(0, 10);
    const labels = topRoutes.map(route => route.route);
    const frequencies = topRoutes.map(route => route.frequency);
    
    chartInstances.routesChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Flight Frequency',
                data: frequencies,
                backgroundColor: colorSchemes.primary.slice(0, topRoutes.length),
                borderColor: colorSchemes.primary.slice(0, topRoutes.length),
                borderWidth: 1,
                borderRadius: 4,
                borderSkipped: false
            }]
        },
        options: {
            ...defaultOptions,
            plugins: {
                ...defaultOptions.plugins,
                title: {
                    display: true,
                    text: 'Top Flight Routes by Frequency'
                }
            },
            scales: {
                ...defaultOptions.scales,
                x: {
                    ...defaultOptions.scales.x,
                    ticks: {
                        maxRotation: 45,
                        minRotation: 45
                    }
                }
            },
            onClick: (event, elements) => {
                if (elements.length > 0) {
                    const index = elements[0].index;
                    const route = topRoutes[index];
                    showRouteDetails(route);
                }
            }
        }
    });
}

/**
 * Create airlines chart (doughnut chart)
 */
function createAirlinesChart(routeData) {
    const ctx = document.getElementById('airlinesChart');
    if (!ctx) return;
    
    // Destroy existing chart
    if (chartInstances.airlinesChart) {
        chartInstances.airlinesChart.destroy();
    }
    
    if (!routeData || routeData.length === 0) {
        showEmptyChart(ctx, 'No airline data available');
        return;
    }
    
    // Count flights by airline (simplified - in real app would come from API)
    const airlineCount = {};
    routeData.forEach(route => {
        // This is a simplified approach - in real implementation, 
        // airline data would come from the route data
        const airline = route.airline || 'Unknown';
        airlineCount[airline] = (airlineCount[airline] || 0) + route.frequency;
    });
    
    const airlines = Object.keys(airlineCount);
    const counts = Object.values(airlineCount);
    
    chartInstances.airlinesChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: airlines,
            datasets: [{
                data: counts,
                backgroundColor: colorSchemes.airlines.slice(0, airlines.length),
                borderColor: '#fff',
                borderWidth: 2,
                hoverBorderWidth: 3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        usePointStyle: true,
                        padding: 15,
                        generateLabels: function(chart) {
                            const data = chart.data;
                            const total = data.datasets[0].data.reduce((a, b) => a + b, 0);
                            return data.labels.map((label, index) => {
                                const value = data.datasets[0].data[index];
                                const percentage = ((value / total) * 100).toFixed(1);
                                return {
                                    text: `${label} (${percentage}%)`,
                                    fillStyle: data.datasets[0].backgroundColor[index],
                                    strokeStyle: data.datasets[0].borderColor,
                                    lineWidth: data.datasets[0].borderWidth,
                                    hidden: false,
                                    index: index
                                };
                            });
                        }
                    }
                },
                title: {
                    display: true,
                    text: 'Market Share by Airline'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((context.parsed / total) * 100).toFixed(1);
                            return `${context.label}: ${context.parsed} flights (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
}

/**
 * Create price trends chart (line chart)
 */
function createPriceChart(priceData) {
    const ctx = document.getElementById('priceChart');
    if (!ctx) return;
    
    // Destroy existing chart
    if (chartInstances.priceChart) {
        chartInstances.priceChart.destroy();
    }
    
    if (!priceData || priceData.length === 0) {
        showEmptyChart(ctx, 'No price trend data available');
        return;
    }
    
    // Group price data by route
    const routeData = {};
    priceData.forEach(trend => {
        if (!routeData[trend.route]) {
            routeData[trend.route] = [];
        }
        routeData[trend.route].push(trend);
    });
    
    // Create datasets for top 5 routes
    const topRoutes = Object.keys(routeData).slice(0, 5);
    const datasets = topRoutes.map((route, index) => ({
        label: route,
        data: routeData[route].map(item => ({
            x: item.date,
            y: item.price
        })),
        borderColor: colorSchemes.primary[index],
        backgroundColor: colorSchemes.primary[index] + '20',
        fill: false,
        tension: 0.4,
        pointRadius: 4,
        pointHoverRadius: 6
    }));
    
    chartInstances.priceChart = new Chart(ctx, {
        type: 'line',
        data: {
            datasets: datasets
        },
        options: {
            ...defaultOptions,
            plugins: {
                ...defaultOptions.plugins,
                title: {
                    display: true,
                    text: 'Price Trends by Route'
                }
            },
            scales: {
                x: {
                    type: 'time',
                    time: {
                        unit: 'day',
                        displayFormats: {
                            day: 'MMM dd'
                        }
                    },
                    title: {
                        display: true,
                        text: 'Date'
                    }
                },
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Price (AUD)'
                    },
                    ticks: {
                        callback: function(value) {
                            return '$' + value.toFixed(0);
                        }
                    }
                }
            },
            interaction: {
                mode: 'index',
                intersect: false
            }
        }
    });
}

/**
 * Create heatmap using Plotly.js
 */
function createHeatmap(heatmapData) {
    const heatmapDiv = document.getElementById('heatmapChart');
    if (!heatmapDiv) return;
    
    if (!heatmapData || heatmapData.length === 0) {
        heatmapDiv.innerHTML = '<div class="text-center text-muted p-4">No heatmap data available</div>';
        return;
    }
    
    // Prepare data for heatmap
    const cities = heatmapData.map(item => item.city);
    const demands = heatmapData.map(item => item.demand);
    const intensities = heatmapData.map(item => item.intensity);
    
    // Create a simple bar chart as heatmap alternative
    const trace = {
        x: cities,
        y: demands,
        type: 'bar',
        marker: {
            color: intensities,
            colorscale: 'Viridis',
            showscale: true,
            colorbar: {
                title: 'Demand Intensity'
            }
        },
        text: demands.map(d => `${d} flights`),
        textposition: 'auto',
        hovertemplate: '<b>%{x}</b><br>Demand: %{y}<br>Intensity: %{marker.color:.2f}<extra></extra>'
    };
    
    const layout = {
        title: {
            text: 'Flight Demand Heatmap by City',
            x: 0.5
        },
        xaxis: {
            title: 'Cities',
            tickangle: -45
        },
        yaxis: {
            title: 'Flight Demand'
        },
        showlegend: false,
        plot_bgcolor: 'rgba(0,0,0,0)',
        paper_bgcolor: 'rgba(0,0,0,0)',
        font: {
            color: '#666'
        }
    };
    
    const config = {
        responsive: true,
        displayModeBar: false
    };
    
    Plotly.newPlot(heatmapDiv, [trace], layout, config);
}

/**
 * Create seasonal analysis chart
 */
function createSeasonalChart(seasonalData) {
    const ctx = document.getElementById('seasonalChart');
    if (!ctx) return;
    
    // Destroy existing chart
    if (chartInstances.seasonalChart) {
        chartInstances.seasonalChart.destroy();
    }
    
    if (!seasonalData) {
        showEmptyChart(ctx, 'No seasonal data available');
        return;
    }
    
    const seasons = Object.keys(seasonalData);
    const flights = seasons.map(season => seasonalData[season].flights);
    const routes = seasons.map(season => seasonalData[season].unique_routes);
    
    chartInstances.seasonalChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: seasons.map(s => s.charAt(0).toUpperCase() + s.slice(1)),
            datasets: [{
                label: 'Flights',
                data: flights,
                backgroundColor: 'rgba(54, 162, 235, 0.6)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1,
                yAxisID: 'y'
            }, {
                label: 'Unique Routes',
                data: routes,
                backgroundColor: 'rgba(255, 99, 132, 0.6)',
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1,
                yAxisID: 'y1'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Seasonal Flight Patterns'
                },
                legend: {
                    position: 'top'
                }
            },
            scales: {
                y: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    title: {
                        display: true,
                        text: 'Number of Flights'
                    }
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    title: {
                        display: true,
                        text: 'Unique Routes'
                    },
                    grid: {
                        drawOnChartArea: false
                    }
                }
            }
        }
    });
}

/**
 * Create market share chart for insights page
 */
function createMarketShareChart(marketShareData) {
    const ctx = document.getElementById('marketShareChart');
    if (!ctx) return;
    
    // Destroy existing chart
    if (chartInstances.marketShareChart) {
        chartInstances.marketShareChart.destroy();
    }
    
    if (!marketShareData || Object.keys(marketShareData).length === 0) {
        showEmptyChart(ctx, 'No market share data available');
        return;
    }
    
    const airlines = Object.keys(marketShareData);
    const shares = Object.values(marketShareData);
    
    chartInstances.marketShareChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: airlines,
            datasets: [{
                data: shares,
                backgroundColor: colorSchemes.airlines.slice(0, airlines.length),
                borderColor: '#fff',
                borderWidth: 2,
                hoverBorderWidth: 3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        usePointStyle: true,
                        padding: 15,
                        generateLabels: function(chart) {
                            const data = chart.data;
                            return data.labels.map((label, index) => {
                                const value = data.datasets[0].data[index];
                                return {
                                    text: `${label} (${value.toFixed(1)}%)`,
                                    fillStyle: data.datasets[0].backgroundColor[index],
                                    strokeStyle: data.datasets[0].borderColor,
                                    lineWidth: data.datasets[0].borderWidth,
                                    hidden: false,
                                    index: index
                                };
                            });
                        }
                    }
                },
                title: {
                    display: true,
                    text: 'Airline Market Share'
                }
            }
        }
    });
}

/**
 * Show empty chart message
 */
function showEmptyChart(ctx, message) {
    const context = ctx.getContext('2d');
    context.clearRect(0, 0, ctx.width, ctx.height);
    context.font = '16px Arial';
    context.fillStyle = '#666';
    context.textAlign = 'center';
    context.fillText(message, ctx.width / 2, ctx.height / 2);
}

/**
 * Show route details modal
 */
function showRouteDetails(route) {
    // This would typically show a modal with detailed route information
    console.log('Route details:', route);
    
    // For now, just show an alert
    alert(`Route: ${route.route}\nFrequency: ${route.frequency}\nOrigin: ${route.origin}\nDestination: ${route.destination}`);
}

/**
 * Resize all charts
 */
function resizeCharts() {
    Object.values(chartInstances).forEach(chart => {
        if (chart && typeof chart.resize === 'function') {
            chart.resize();
        }
    });
}

/**
 * Destroy all charts
 */
function destroyAllCharts() {
    Object.values(chartInstances).forEach(chart => {
        if (chart && typeof chart.destroy === 'function') {
            chart.destroy();
        }
    });
    chartInstances = {};
}

/**
 * Update chart colors for theme changes
 */
function updateChartColors(isDark) {
    const textColor = isDark ? '#fff' : '#666';
    const gridColor = isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)';
    
    Object.values(chartInstances).forEach(chart => {
        if (chart && chart.options) {
            if (chart.options.scales) {
                if (chart.options.scales.x) {
                    chart.options.scales.x.ticks.color = textColor;
                    chart.options.scales.x.grid.color = gridColor;
                }
                if (chart.options.scales.y) {
                    chart.options.scales.y.ticks.color = textColor;
                    chart.options.scales.y.grid.color = gridColor;
                }
            }
            chart.update();
        }
    });
}

// Handle window resize
window.addEventListener('resize', debounce(resizeCharts, 250));

// Handle theme changes
document.addEventListener('DOMContentLoaded', function() {
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.type === 'attributes' && mutation.attributeName === 'data-bs-theme') {
                const isDark = document.documentElement.getAttribute('data-bs-theme') === 'dark';
                updateChartColors(isDark);
            }
        });
    });
    
    observer.observe(document.documentElement, {
        attributes: true,
        attributeFilter: ['data-bs-theme']
    });
});

// Debounce function for resize handling
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Export functions for global use
window.ChartsJS = {
    createRoutesChart,
    createAirlinesChart,
    createPriceChart,
    createHeatmap,
    createSeasonalChart,
    createMarketShareChart,
    resizeCharts,
    destroyAllCharts,
    updateChartColors
};
