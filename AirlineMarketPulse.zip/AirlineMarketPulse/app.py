import os
import logging
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from werkzeug.middleware.proxy_fix import ProxyFix
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
import atexit
import json
from datetime import datetime, timedelta

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Import routes after app creation to avoid circular imports
from routes.dashboard import dashboard_bp
from routes.insights import insights_bp
from services.data_collector import DataCollector
from services.ai_analyzer import AIAnalyzer
from utils.data_processor import DataProcessor

# Register blueprints
app.register_blueprint(dashboard_bp)
app.register_blueprint(insights_bp)

# Initialize services
data_collector = DataCollector()
ai_analyzer = AIAnalyzer()
data_processor = DataProcessor()

# Global data storage (in-memory for MVP)
app.flight_data = []
app.route_analysis = {}
app.price_trends = {}
app.ai_insights = {}
app.last_updated = None

# Australian major cities and airports
AUSTRALIAN_CITIES = {
    'Sydney': {'code': 'SYD', 'lat': -33.8688, 'lon': 151.2093},
    'Melbourne': {'code': 'MEL', 'lat': -37.8136, 'lon': 144.9631},
    'Brisbane': {'code': 'BNE', 'lat': -27.4698, 'lon': 153.0251},
    'Perth': {'code': 'PER', 'lat': -31.9505, 'lon': 115.8605},
    'Adelaide': {'code': 'ADL', 'lat': -34.9285, 'lon': 138.6007},
    'Gold Coast': {'code': 'OOL', 'lat': -28.0167, 'lon': 153.4000},
    'Cairns': {'code': 'CNS', 'lat': -16.9186, 'lon': 145.7781},
    'Darwin': {'code': 'DRW', 'lat': -12.4634, 'lon': 130.8456},
    'Hobart': {'code': 'HBA', 'lat': -42.8821, 'lon': 147.3272},
    'Canberra': {'code': 'CBR', 'lat': -35.2809, 'lon': 149.1300}
}

def collect_and_analyze_data():
    """Background task to collect and analyze data"""
    try:
        logger.info("Starting data collection and analysis...")
        
        # Collect flight data
        flight_data = data_collector.collect_flight_data(AUSTRALIAN_CITIES)
        if flight_data:
            app.flight_data = flight_data
            logger.info(f"Collected {len(flight_data)} flight records")
        
        # Analyze routes and trends
        if app.flight_data:
            app.route_analysis = data_processor.analyze_routes(app.flight_data)
            app.price_trends = data_processor.analyze_price_trends(app.flight_data)
            
            # Generate AI insights
            insights_data = {
                'routes': app.route_analysis,
                'trends': app.price_trends,
                'flight_data': app.flight_data[:100]  # Limit data for AI analysis
            }
            app.ai_insights = ai_analyzer.generate_business_insights(insights_data)
            
        app.last_updated = datetime.now()
        logger.info("Data collection and analysis completed successfully")
        
    except Exception as e:
        logger.error(f"Error in data collection: {str(e)}")

@app.route('/')
def index():
    """Main landing page"""
    return render_template('index.html', 
                         cities=AUSTRALIAN_CITIES,
                         last_updated=app.last_updated)

@app.route('/api/data/summary')
def api_data_summary():
    """API endpoint for dashboard summary data"""
    try:
        summary = {
            'total_flights': len(app.flight_data),
            'total_routes': len(app.route_analysis),
            'last_updated': app.last_updated.isoformat() if app.last_updated else None,
            'popular_routes': list(app.route_analysis.keys())[:10] if app.route_analysis else [],
            'cities_count': len(AUSTRALIAN_CITIES)
        }
        return jsonify(summary)
    except Exception as e:
        logger.error(f"Error getting data summary: {str(e)}")
        return jsonify({'error': 'Failed to get data summary'}), 500

@app.route('/api/data/export')
def export_data():
    """Export data as CSV"""
    try:
        import csv
        import io
        from flask import make_response
        
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Write headers
        writer.writerow(['Route', 'Origin', 'Destination', 'Frequency', 'Average_Price', 'Peak_Season'])
        
        # Write route data
        for route, data in app.route_analysis.items():
            writer.writerow([
                route,
                data.get('origin', ''),
                data.get('destination', ''),
                data.get('frequency', 0),
                data.get('average_price', 0),
                data.get('peak_season', '')
            ])
        
        output.seek(0)
        response = make_response(output.getvalue())
        response.headers['Content-Type'] = 'text/csv'
        response.headers['Content-Disposition'] = f'attachment; filename=airline_data_{datetime.now().strftime("%Y%m%d")}.csv'
        return response
        
    except Exception as e:
        logger.error(f"Error exporting data: {str(e)}")
        return jsonify({'error': 'Failed to export data'}), 500

# Initialize scheduler for background data collection
scheduler = BackgroundScheduler()
scheduler.start()

# Schedule data collection every 30 minutes
scheduler.add_job(
    func=collect_and_analyze_data,
    trigger=IntervalTrigger(minutes=30),
    id='data_collection_job',
    name='Collect and analyze airline data',
    replace_existing=True
)

# Run initial data collection
collect_and_analyze_data()

# Shut down the scheduler when exiting the app
atexit.register(lambda: scheduler.shutdown())

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
