import trafilatura
import requests
import logging
from typing import Dict, List, Optional
from bs4 import BeautifulSoup
import re
from datetime import datetime

logger = logging.getLogger(__name__)

class WebScraper:
    """Service for scraping airline and travel data from websites"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
    
    def get_website_text_content(self, url: str) -> str:
        """
        Extract main text content from a website URL
        Uses trafilatura for clean text extraction
        """
        try:
            downloaded = trafilatura.fetch_url(url)
            if downloaded:
                text = trafilatura.extract(downloaded)
                return text or ""
            return ""
        except Exception as e:
            logger.error(f"Error extracting content from {url}: {str(e)}")
            return ""
    
    def scrape_airline_routes(self, airline_urls: List[str]) -> List[Dict]:
        """Scrape airline route information from multiple websites"""
        routes = []
        
        for url in airline_urls:
            try:
                content = self.get_website_text_content(url)
                if content:
                    # Extract route information from text content
                    extracted_routes = self._extract_routes_from_text(content)
                    routes.extend(extracted_routes)
                    
            except Exception as e:
                logger.error(f"Error scraping {url}: {str(e)}")
                continue
                
        return routes
    
    def scrape_travel_trends(self, travel_sites: List[str]) -> Dict:
        """Scrape travel trend information from travel websites"""
        trends = {
            'popular_destinations': [],
            'seasonal_patterns': [],
            'price_insights': []
        }
        
        for site in travel_sites:
            try:
                content = self.get_website_text_content(site)
                if content:
                    # Extract trend information
                    site_trends = self._extract_trends_from_text(content)
                    
                    # Merge trends
                    for key in trends:
                        if key in site_trends:
                            trends[key].extend(site_trends[key])
                            
            except Exception as e:
                logger.error(f"Error scraping travel trends from {site}: {str(e)}")
                continue
                
        return trends
    
    def scrape_airport_info(self, airport_codes: List[str]) -> Dict:
        """Scrape airport information and flight statistics"""
        airport_info = {}
        
        for code in airport_codes:
            try:
                # Scrape from multiple airport information sources
                urls = [
                    f"https://www.flightradar24.com/data/airports/{code.lower()}",
                    f"https://www.airport-data.com/airport/{code.upper()}/"
                ]
                
                for url in urls:
                    try:
                        response = self.session.get(url, timeout=10)
                        if response.status_code == 200:
                            soup = BeautifulSoup(response.content, 'html.parser')
                            
                            # Extract basic airport information
                            info = self._extract_airport_info(soup, code)
                            if info:
                                airport_info[code] = info
                                break
                                
                    except Exception as e:
                        logger.warning(f"Failed to scrape {url}: {str(e)}")
                        continue
                        
            except Exception as e:
                logger.error(f"Error scraping airport info for {code}: {str(e)}")
                continue
                
        return airport_info
    
    def _extract_routes_from_text(self, text: str) -> List[Dict]:
        """Extract route information from text content"""
        routes = []
        
        # Look for common route patterns
        route_patterns = [
            r'([A-Z]{3})\s*[-to]\s*([A-Z]{3})',  # SYD-MEL format
            r'([A-Za-z]+)\s*to\s*([A-Za-z]+)',   # Sydney to Melbourne format
            r'([A-Za-z]+)\s*[-–]\s*([A-Za-z]+)'  # Sydney - Melbourne format
        ]
        
        for pattern in route_patterns:
            matches = re.findall(pattern, text)
            for match in matches:
                routes.append({
                    'origin': match[0].strip(),
                    'destination': match[1].strip(),
                    'source': 'web_scraping',
                    'extracted_at': datetime.now().isoformat()
                })
                
        return routes
    
    def _extract_trends_from_text(self, text: str) -> Dict:
        """Extract travel trend information from text"""
        trends = {
            'popular_destinations': [],
            'seasonal_patterns': [],
            'price_insights': []
        }
        
        # Look for destination mentions
        australian_cities = ['Sydney', 'Melbourne', 'Brisbane', 'Perth', 'Adelaide', 'Gold Coast', 'Cairns', 'Darwin', 'Hobart', 'Canberra']
        
        for city in australian_cities:
            if city.lower() in text.lower():
                trends['popular_destinations'].append(city)
        
        # Look for seasonal patterns
        seasonal_keywords = ['summer', 'winter', 'spring', 'autumn', 'holiday', 'peak', 'season']
        for keyword in seasonal_keywords:
            if keyword in text.lower():
                trends['seasonal_patterns'].append(keyword)
        
        # Look for price-related information
        price_keywords = ['price', 'cost', 'fare', 'cheap', 'expensive', 'deal', 'discount']
        for keyword in price_keywords:
            if keyword in text.lower():
                trends['price_insights'].append(keyword)
        
        return trends
    
    def _extract_airport_info(self, soup: BeautifulSoup, code: str) -> Optional[Dict]:
        """Extract airport information from HTML"""
        try:
            info = {
                'code': code,
                'scraped_at': datetime.now().isoformat()
            }
            
            # Try to find airport name
            title_tags = soup.find_all(['title', 'h1', 'h2'])
            for tag in title_tags:
                if tag.text and code in tag.text:
                    info['name'] = tag.text.strip()
                    break
            
            # Try to find statistics
            stats_keywords = ['flights', 'passengers', 'arrivals', 'departures']
            for keyword in stats_keywords:
                elements = soup.find_all(text=re.compile(keyword, re.IGNORECASE))
                if elements:
                    info[f'{keyword}_info'] = str(elements[0]).strip()
            
            return info if len(info) > 2 else None
            
        except Exception as e:
            logger.error(f"Error extracting airport info: {str(e)}")
            return None
    
    def scrape_qantas_routes(self) -> List[Dict]:
        """Scrape Qantas route information"""
        try:
            url = "https://www.qantas.com/au/en/travel-info/travel-tips/destinations.html"
            content = self.get_website_text_content(url)
            
            if content:
                routes = self._extract_routes_from_text(content)
                for route in routes:
                    route['airline'] = 'Qantas'
                return routes
                
        except Exception as e:
            logger.error(f"Error scraping Qantas routes: {str(e)}")
            
        return []
    
    def scrape_jetstar_routes(self) -> List[Dict]:
        """Scrape Jetstar route information"""
        try:
            url = "https://www.jetstar.com/au/en/destinations"
            content = self.get_website_text_content(url)
            
            if content:
                routes = self._extract_routes_from_text(content)
                for route in routes:
                    route['airline'] = 'Jetstar'
                return routes
                
        except Exception as e:
            logger.error(f"Error scraping Jetstar routes: {str(e)}")
            
        return []
