import os
import json
import logging
from typing import Dict, List, Any
from openai import OpenAI
from models import AIInsight

logger = logging.getLogger(__name__)

class AIAnalyzer:
    """Service for AI-powered analysis of airline data"""
    
    def __init__(self):
        self.openai_api_key = os.environ.get("OPENAI_API_KEY", "")
        self.client = OpenAI(api_key=self.openai_api_key) if self.openai_api_key else None
        
    def generate_business_insights(self, data: Dict) -> Dict[str, Any]:
        """Generate AI-powered business insights from airline data"""
        if not self.client:
            logger.warning("OpenAI API key not available, returning mock insights")
            return self._generate_fallback_insights(data)
            
        try:
            # Prepare data summary for AI analysis
            data_summary = self._prepare_data_summary(data)
            
            # Generate insights using GPT-4o
            insights = self._analyze_with_gpt(data_summary)
            
            return insights
            
        except Exception as e:
            logger.error(f"Error generating AI insights: {str(e)}")
            return self._generate_fallback_insights(data)
    
    def _prepare_data_summary(self, data: Dict) -> str:
        """Prepare data summary for AI analysis"""
        summary = {
            'total_routes': len(data.get('routes', {})),
            'popular_routes': list(data.get('routes', {}).keys())[:10],
            'price_trends': data.get('trends', {}),
            'flight_count': len(data.get('flight_data', [])),
            'airlines': list(set([f.get('airline', '') for f in data.get('flight_data', [])]))
        }
        
        return json.dumps(summary, indent=2)
    
    def _analyze_with_gpt(self, data_summary: str) -> Dict[str, Any]:
        """Analyze data using GPT-4o and generate business insights"""
        try:
            prompt = f"""
            As an expert airline industry analyst, analyze the following Australian airline market data and provide strategic business insights for a network of hostels across Australia.

            Data Summary:
            {data_summary}

            Please provide insights in the following categories:
            1. Route Popularity Analysis
            2. Seasonal Demand Patterns
            3. Pricing Trends
            4. Business Opportunities for Hostels
            5. Strategic Recommendations

            For each insight, provide:
            - A clear title
            - Description of the trend or pattern
            - Specific business recommendation
            - Confidence level (0-1)
            - Expected business impact

            Respond in JSON format with the following structure:
            {{
                "insights": [
                    {{
                        "category": "category_name",
                        "title": "insight_title",
                        "description": "detailed_description",
                        "recommendation": "actionable_recommendation",
                        "confidence": 0.95,
                        "business_impact": "high/medium/low"
                    }}
                ],
                "summary": "overall_market_summary",
                "key_opportunities": ["opportunity1", "opportunity2"]
            }}
            """
            
            # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
            # do not change this unless explicitly requested by the user
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": "You are an expert airline industry analyst specializing in Australian market trends and hostel business strategy."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"},
                temperature=0.7
            )
            
            result = json.loads(response.choices[0].message.content)
            logger.info("Successfully generated AI insights")
            return result
            
        except Exception as e:
            logger.error(f"Error in GPT analysis: {str(e)}")
            return self._generate_fallback_insights({})
    
    def _generate_fallback_insights(self, data: Dict) -> Dict[str, Any]:
        """Generate fallback insights when AI is not available"""
        return {
            "insights": [
                {
                    "category": "Route Popularity",
                    "title": "Sydney-Melbourne Route Dominance",
                    "description": "The Sydney-Melbourne route consistently shows the highest demand across all data sources.",
                    "recommendation": "Consider establishing hostels near airports in both cities to capture transit passengers.",
                    "confidence": 0.8,
                    "business_impact": "high"
                },
                {
                    "category": "Seasonal Patterns",
                    "title": "Summer Peak Season",
                    "description": "Australian summer months show increased domestic travel activity.",
                    "recommendation": "Optimize pricing and availability during December-February period.",
                    "confidence": 0.7,
                    "business_impact": "medium"
                },
                {
                    "category": "Business Opportunities",
                    "title": "Airport Transit Market",
                    "description": "Increasing number of connecting flights creates opportunity for short-stay accommodation.",
                    "recommendation": "Develop partnerships with airlines for passenger accommodation during layovers.",
                    "confidence": 0.75,
                    "business_impact": "high"
                }
            ],
            "summary": "Australian airline market shows strong domestic demand with opportunities for hostel businesses near major airports.",
            "key_opportunities": [
                "Airport proximity locations",
                "Seasonal pricing optimization",
                "Corporate traveler packages"
            ]
        }
    
    def analyze_route_performance(self, route_data: Dict) -> Dict:
        """Analyze specific route performance"""
        if not self.client:
            return {"status": "AI analysis not available"}
            
        try:
            prompt = f"""
            Analyze this specific route data and provide insights:
            {json.dumps(route_data, indent=2)}
            
            Provide a JSON response with:
            - performance_score (0-100)
            - growth_potential (high/medium/low)
            - recommendations (list of strings)
            - risk_factors (list of strings)
            """
            
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": prompt}],
                response_format={"type": "json_object"}
            )
            
            return json.loads(response.choices[0].message.content)
            
        except Exception as e:
            logger.error(f"Error analyzing route performance: {str(e)}")
            return {"status": "Analysis failed", "error": str(e)}
