import requests
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import os
import json
from models import FlightData

logger = logging.getLogger(__name__)

class DataCollector:
    """Service for collecting flight data from various APIs"""
    
    def __init__(self):
        self.opensky_base_url = "https://opensky-network.org/api"
        self.aviationstack_key = os.environ.get("AVIATIONSTACK_API_KEY", "")
        self.aviationstack_base_url = "http://api.aviationstack.com/v1"
        
    def collect_flight_data(self, cities: Dict) -> List[Dict]:
        """Collect flight data from multiple sources"""
        all_flights = []
        
        try:
            # Collect from OpenSky Network
            opensky_flights = self._collect_from_opensky(cities)
            all_flights.extend(opensky_flights)
            
            # Collect from AviationStack if API key is available
            if self.aviationstack_key:
                aviationstack_flights = self._collect_from_aviationstack(cities)
                all_flights.extend(aviationstack_flights)
            
            logger.info(f"Collected {len(all_flights)} flights total")
            return all_flights
            
        except Exception as e:
            logger.error(f"Error collecting flight data: {str(e)}")
            return []
    
    def _collect_from_opensky(self, cities: Dict) -> List[Dict]:
        """Collect flight data from OpenSky Network API"""
        flights = []
        
        try:
            # Get current flights over Australia
            url = f"{self.opensky_base_url}/states/all"
            params = {
                'lamin': -44.0,  # Southern boundary of Australia
                'lomin': 113.0,  # Western boundary
                'lamax': -10.0,  # Northern boundary
                'lomax': 154.0   # Eastern boundary
            }
            
            response = requests.get(url, params=params, timeout=30)
            if response.status_code == 200:
                data = response.json()
                
                if data and 'states' in data and data['states']:
                    for state in data['states']:
                        if len(state) >= 13:  # Ensure we have enough data
                            flight = {
                                'flight_number': state[1] or f"OS{state[0]}",
                                'origin': self._get_nearest_city(state[6], state[5], cities),
                                'destination': 'Unknown',
                                'airline': self._extract_airline(state[1]),
                                'aircraft_type': 'Unknown',
                                'departure_time': datetime.now(),
                                'arrival_time': datetime.now() + timedelta(hours=2),
                                'price': None,
                                'availability': None,
                                'latitude': state[6],
                                'longitude': state[5],
                                'altitude': state[7],
                                'velocity': state[9]
                            }
                            flights.append(flight)
                    
                    logger.info(f"Collected {len(flights)} flights from OpenSky")
                else:
                    logger.warning("No flight data received from OpenSky")
            else:
                logger.error(f"OpenSky API error: {response.status_code}")
                
        except Exception as e:
            logger.error(f"Error collecting from OpenSky: {str(e)}")
            
        return flights
    
    def _collect_from_aviationstack(self, cities: Dict) -> List[Dict]:
        """Collect flight data from AviationStack API"""
        flights = []
        
        try:
            # Get flights for major Australian airports
            major_airports = ['SYD', 'MEL', 'BNE', 'PER', 'ADL']
            
            for airport in major_airports:
                url = f"{self.aviationstack_base_url}/flights"
                params = {
                    'access_key': self.aviationstack_key,
                    'dep_iata': airport,
                    'limit': 20
                }
                
                response = requests.get(url, params=params, timeout=30)
                if response.status_code == 200:
                    data = response.json()
                    
                    if 'data' in data and data['data']:
                        for flight_data in data['data']:
                            flight = {
                                'flight_number': flight_data.get('flight', {}).get('number', ''),
                                'origin': flight_data.get('departure', {}).get('iata', ''),
                                'destination': flight_data.get('arrival', {}).get('iata', ''),
                                'airline': flight_data.get('airline', {}).get('name', ''),
                                'aircraft_type': flight_data.get('aircraft', {}).get('registration', ''),
                                'departure_time': self._parse_datetime(flight_data.get('departure', {}).get('scheduled')),
                                'arrival_time': self._parse_datetime(flight_data.get('arrival', {}).get('scheduled')),
                                'price': None,
                                'availability': None,
                                'status': flight_data.get('flight_status', '')
                            }
                            flights.append(flight)
                
                logger.info(f"Collected {len(flights)} flights from AviationStack for {airport}")
                
        except Exception as e:
            logger.error(f"Error collecting from AviationStack: {str(e)}")
            
        return flights
    
    def _get_nearest_city(self, lat: float, lon: float, cities: Dict) -> str:
        """Find the nearest city based on coordinates"""
        if not lat or not lon:
            return "Unknown"
            
        min_distance = float('inf')
        nearest_city = "Unknown"
        
        for city, info in cities.items():
            distance = ((lat - info['lat']) ** 2 + (lon - info['lon']) ** 2) ** 0.5
            if distance < min_distance:
                min_distance = distance
                nearest_city = city
                
        return nearest_city
    
    def _extract_airline(self, callsign: str) -> str:
        """Extract airline from callsign"""
        if not callsign:
            return "Unknown"
            
        # Common Australian airline codes
        airline_codes = {
            'QFA': 'Qantas',
            'JST': 'Jetstar',
            'VOZ': 'Virgin Australia',
            'TGW': 'Tigerair Australia',
            'REX': 'Regional Express',
            'JQ': 'Jetstar',
            'VA': 'Virgin Australia',
            'QF': 'Qantas'
        }
        
        callsign = callsign.strip()
        for code, airline in airline_codes.items():
            if callsign.startswith(code):
                return airline
                
        return "Unknown"
    
    def _parse_datetime(self, datetime_str: str) -> datetime:
        """Parse datetime string from API"""
        if not datetime_str:
            return datetime.now()
            
        try:
            # Try different datetime formats
            formats = [
                '%Y-%m-%dT%H:%M:%S%z',
                '%Y-%m-%dT%H:%M:%S.%f%z',
                '%Y-%m-%dT%H:%M:%S',
                '%Y-%m-%d %H:%M:%S'
            ]
            
            for fmt in formats:
                try:
                    return datetime.strptime(datetime_str, fmt)
                except ValueError:
                    continue
                    
            return datetime.now()
            
        except Exception:
            return datetime.now()
