from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Optional

@dataclass
class FlightData:
    """Model for flight data"""
    origin: str
    destination: str
    departure_time: datetime
    arrival_time: datetime
    airline: str
    aircraft_type: str
    flight_number: str
    price: Optional[float] = None
    availability: Optional[int] = None
    
    def to_dict(self) -> Dict:
        return {
            'origin': self.origin,
            'destination': self.destination,
            'departure_time': self.departure_time.isoformat(),
            'arrival_time': self.arrival_time.isoformat(),
            'airline': self.airline,
            'aircraft_type': self.aircraft_type,
            'flight_number': self.flight_number,
            'price': self.price,
            'availability': self.availability
        }

@dataclass
class RouteAnalysis:
    """Model for route analysis data"""
    route: str
    origin: str
    destination: str
    frequency: int
    average_price: float
    peak_season: str
    demand_trend: str
    
    def to_dict(self) -> Dict:
        return {
            'route': self.route,
            'origin': self.origin,
            'destination': self.destination,
            'frequency': self.frequency,
            'average_price': self.average_price,
            'peak_season': self.peak_season,
            'demand_trend': self.demand_trend
        }

@dataclass
class PriceTrend:
    """Model for price trend data"""
    route: str
    date: datetime
    average_price: float
    min_price: float
    max_price: float
    
    def to_dict(self) -> Dict:
        return {
            'route': self.route,
            'date': self.date.isoformat(),
            'average_price': self.average_price,
            'min_price': self.min_price,
            'max_price': self.max_price
        }

@dataclass
class AIInsight:
    """Model for AI-generated insights"""
    category: str
    title: str
    description: str
    recommendation: str
    confidence: float
    business_impact: str
    
    def to_dict(self) -> Dict:
        return {
            'category': self.category,
            'title': self.title,
            'description': self.description,
            'recommendation': self.recommendation,
            'confidence': self.confidence,
            'business_impact': self.business_impact
        }
