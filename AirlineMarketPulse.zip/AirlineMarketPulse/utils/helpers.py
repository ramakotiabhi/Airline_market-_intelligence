from datetime import datetime, timedelta
from typing import List, Dict, Any
import logging

logger = logging.getLogger(__name__)

def filter_data_by_date(flight_data: List[Dict], start_date: str, end_date: str) -> List[Dict]:
    """Filter flight data by date range"""
    try:
        start = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
        end = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
        
        filtered_data = []
        
        for flight in flight_data:
            flight_date = flight.get('departure_time')
            
            if isinstance(flight_date, str):
                try:
                    flight_date = datetime.fromisoformat(flight_date.replace('Z', '+00:00'))
                except:
                    continue
            elif isinstance(flight_date, datetime):
                pass
            else:
                continue
            
            if start <= flight_date <= end:
                filtered_data.append(flight)
        
        return filtered_data
        
    except Exception as e:
        logger.error(f"Error filtering data by date: {str(e)}")
        return flight_data

def format_currency(amount: float, currency: str = 'AUD') -> str:
    """Format currency amount"""
    try:
        if amount is None:
            return 'N/A'
        
        return f"{currency} ${amount:,.2f}"
        
    except Exception:
        return 'N/A'

def calculate_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculate distance between two coordinates using Haversine formula"""
    try:
        from math import radians, cos, sin, asin, sqrt
        
        # Convert decimal degrees to radians
        lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
        
        # Haversine formula
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
        c = 2 * asin(sqrt(a))
        
        # Radius of earth in kilometers
        r = 6371
        
        return c * r
        
    except Exception as e:
        logger.error(f"Error calculating distance: {str(e)}")
        return 0.0

def get_australian_timezone_offset() -> int:
    """Get timezone offset for Australian Eastern Time"""
    try:
        # This is a simplified implementation
        # In production, you would use a proper timezone library
        return 10  # AEST is UTC+10
        
    except Exception:
        return 0

def validate_airport_code(code: str) -> bool:
    """Validate airport code format"""
    try:
        if not code or len(code) != 3:
            return False
        
        return code.isalpha() and code.isupper()
        
    except Exception:
        return False

def sanitize_string(text: str) -> str:
    """Sanitize string for safe display"""
    try:
        if not text:
            return ''
        
        # Remove potentially dangerous characters
        import re
        sanitized = re.sub(r'[<>"\']', '', str(text))
        
        return sanitized.strip()
        
    except Exception:
        return ''

def get_season_from_month(month: int) -> str:
    """Get Australian season from month number"""
    try:
        # Australian seasons (Southern Hemisphere)
        if month in [12, 1, 2]:
            return 'Summer'
        elif month in [3, 4, 5]:
            return 'Autumn'
        elif month in [6, 7, 8]:
            return 'Winter'
        else:
            return 'Spring'
            
    except Exception:
        return 'Unknown'

def paginate_data(data: List[Any], page: int = 1, per_page: int = 50) -> Dict:
    """Paginate data for API responses"""
    try:
        total = len(data)
        start = (page - 1) * per_page
        end = start + per_page
        
        paginated_data = data[start:end]
        
        return {
            'data': paginated_data,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': total,
                'pages': (total + per_page - 1) // per_page,
                'has_next': end < total,
                'has_prev': page > 1
            }
        }
        
    except Exception as e:
        logger.error(f"Error paginating data: {str(e)}")
        return {
            'data': [],
            'pagination': {
                'page': 1,
                'per_page': per_page,
                'total': 0,
                'pages': 0,
                'has_next': False,
                'has_prev': False
            }
        }

def extract_route_info(route_string: str) -> Dict:
    """Extract origin and destination from route string"""
    try:
        if '-' in route_string:
            parts = route_string.split('-', 1)
            return {
                'origin': parts[0].strip(),
                'destination': parts[1].strip(),
                'valid': True
            }
        else:
            return {
                'origin': route_string,
                'destination': '',
                'valid': False
            }
            
    except Exception:
        return {
            'origin': '',
            'destination': '',
            'valid': False
        }

def calculate_growth_rate(current: float, previous: float) -> float:
    """Calculate growth rate between two values"""
    try:
        if previous == 0:
            return 0.0
        
        return ((current - previous) / previous) * 100
        
    except Exception:
        return 0.0

def get_time_period_label(period: str) -> str:
    """Get human-readable label for time period"""
    period_labels = {
        'daily': 'Daily',
        'weekly': 'Weekly',
        'monthly': 'Monthly',
        'quarterly': 'Quarterly',
        'yearly': 'Yearly'
    }
    
    return period_labels.get(period, period.title())
