import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Any
import logging

logger = logging.getLogger(__name__)

class DataProcessor:
    """Utility class for processing and analyzing flight data"""
    
    def __init__(self):
        self.australian_cities = {
            'Sydney': 'SYD', 'Melbourne': 'MEL', 'Brisbane': 'BNE', 
            'Perth': 'PER', 'Adelaide': 'ADL', 'Gold Coast': 'OOL',
            'Cairns': 'CNS', 'Darwin': 'DRW', 'Hobart': 'HBA', 'Canberra': 'CBR'
        }
    
    def analyze_routes(self, flight_data: List[Dict]) -> Dict:
        """Analyze flight routes and calculate statistics"""
        try:
            if not flight_data:
                return {}
            
            # Convert to DataFrame for easier analysis
            df = pd.DataFrame(flight_data)
            
            # Create route identifiers
            df['route'] = df['origin'].astype(str) + '-' + df['destination'].astype(str)
            
            # Filter out invalid routes
            df = df[df['route'] != 'Unknown-Unknown']
            df = df[df['route'] != 'nan-nan']
            
            route_analysis = {}
            
            # Analyze each route
            for route in df['route'].unique():
                route_data = df[df['route'] == route]
                
                if len(route_data) == 0:
                    continue
                
                # Calculate statistics
                frequency = len(route_data)
                airlines = route_data['airline'].nunique()
                
                # Calculate average price if available
                price_data = route_data[route_data['price'].notna()]
                avg_price = price_data['price'].mean() if len(price_data) > 0 else 0
                
                # Determine peak season (simplified logic)
                peak_season = self._determine_peak_season(route_data)
                
                # Analyze demand trend
                demand_trend = self._analyze_demand_trend(route_data)
                
                route_analysis[route] = {
                    'origin': route_data['origin'].iloc[0],
                    'destination': route_data['destination'].iloc[0],
                    'frequency': frequency,
                    'airlines_count': airlines,
                    'average_price': round(avg_price, 2) if avg_price > 0 else None,
                    'peak_season': peak_season,
                    'demand_trend': demand_trend,
                    'last_flight': route_data['departure_time'].max() if 'departure_time' in route_data.columns else None
                }
            
            logger.info(f"Analyzed {len(route_analysis)} routes")
            return route_analysis
            
        except Exception as e:
            logger.error(f"Error analyzing routes: {str(e)}")
            return {}
    
    def analyze_price_trends(self, flight_data: List[Dict]) -> Dict:
        """Analyze price trends over time"""
        try:
            if not flight_data:
                return {}
            
            df = pd.DataFrame(flight_data)
            
            # Filter data with price information
            price_data = df[df['price'].notna()]
            
            if len(price_data) == 0:
                return {}
            
            # Create route identifiers
            price_data['route'] = price_data['origin'].astype(str) + '-' + price_data['destination'].astype(str)
            
            price_trends = {}
            
            # Analyze trends for each route
            for route in price_data['route'].unique():
                route_prices = price_data[price_data['route'] == route]
                
                if len(route_prices) < 2:
                    continue
                
                # Calculate price statistics
                prices = route_prices['price'].values
                
                trend_data = {
                    'route': route,
                    'min_price': float(np.min(prices)),
                    'max_price': float(np.max(prices)),
                    'average_price': float(np.mean(prices)),
                    'median_price': float(np.median(prices)),
                    'price_volatility': float(np.std(prices)),
                    'sample_size': len(prices)
                }
                
                # Calculate trend direction
                if len(prices) > 1:
                    trend_data['trend_direction'] = 'increasing' if prices[-1] > prices[0] else 'decreasing'
                else:
                    trend_data['trend_direction'] = 'stable'
                
                price_trends[route] = trend_data
            
            logger.info(f"Analyzed price trends for {len(price_trends)} routes")
            return price_trends
            
        except Exception as e:
            logger.error(f"Error analyzing price trends: {str(e)}")
            return {}
    
    def calculate_demand_metrics(self, flight_data: List[Dict]) -> Dict:
        """Calculate various demand metrics"""
        try:
            if not flight_data:
                return {}
            
            df = pd.DataFrame(flight_data)
            
            metrics = {
                'total_flights': len(df),
                'unique_routes': df['origin'].astype(str).str.cat(df['destination'].astype(str), sep='-').nunique(),
                'unique_airlines': df['airline'].nunique(),
                'unique_origins': df['origin'].nunique(),
                'unique_destinations': df['destination'].nunique()
            }
            
            # Calculate city-level demand
            city_demand = {}
            
            for _, flight in df.iterrows():
                origin = flight['origin']
                destination = flight['destination']
                
                if pd.notna(origin) and origin != 'Unknown':
                    city_demand[origin] = city_demand.get(origin, 0) + 1
                
                if pd.notna(destination) and destination != 'Unknown':
                    city_demand[destination] = city_demand.get(destination, 0) + 1
            
            # Get top cities by demand
            top_cities = sorted(city_demand.items(), key=lambda x: x[1], reverse=True)[:10]
            
            metrics['city_demand'] = dict(top_cities)
            metrics['busiest_city'] = top_cities[0][0] if top_cities else None
            
            return metrics
            
        except Exception as e:
            logger.error(f"Error calculating demand metrics: {str(e)}")
            return {}
    
    def _determine_peak_season(self, route_data: pd.DataFrame) -> str:
        """Determine peak season for a route (simplified logic)"""
        try:
            # This is a simplified implementation
            # In a real scenario, you would analyze historical data
            
            current_month = datetime.now().month
            
            # Australian seasons (Southern Hemisphere)
            if current_month in [12, 1, 2]:
                return 'Summer'
            elif current_month in [3, 4, 5]:
                return 'Autumn'
            elif current_month in [6, 7, 8]:
                return 'Winter'
            else:
                return 'Spring'
                
        except Exception:
            return 'Unknown'
    
    def _analyze_demand_trend(self, route_data: pd.DataFrame) -> str:
        """Analyze demand trend for a route"""
        try:
            # Simple trend analysis based on frequency
            frequency = len(route_data)
            
            if frequency > 20:
                return 'high'
            elif frequency > 10:
                return 'medium'
            else:
                return 'low'
                
        except Exception:
            return 'stable'
    
    def filter_by_date_range(self, flight_data: List[Dict], start_date: str, end_date: str) -> List[Dict]:
        """Filter flight data by date range"""
        try:
            start = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
            end = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
            
            filtered_data = []
            
            for flight in flight_data:
                flight_date = flight.get('departure_time')
                if isinstance(flight_date, str):
                    try:
                        flight_date = datetime.fromisoformat(flight_date.replace('Z', '+00:00'))
                    except:
                        continue
                elif isinstance(flight_date, datetime):
                    pass
                else:
                    continue
                
                if start <= flight_date <= end:
                    filtered_data.append(flight)
            
            return filtered_data
            
        except Exception as e:
            logger.error(f"Error filtering by date range: {str(e)}")
            return flight_data
    
    def aggregate_by_time_period(self, flight_data: List[Dict], period: str = 'daily') -> Dict:
        """Aggregate flight data by time period"""
        try:
            if not flight_data:
                return {}
            
            df = pd.DataFrame(flight_data)
            
            # Convert departure_time to datetime
            df['departure_time'] = pd.to_datetime(df['departure_time'], errors='coerce')
            df = df.dropna(subset=['departure_time'])
            
            if len(df) == 0:
                return {}
            
            # Group by time period
            if period == 'daily':
                df['period'] = df['departure_time'].dt.date
            elif period == 'weekly':
                df['period'] = df['departure_time'].dt.to_period('W')
            elif period == 'monthly':
                df['period'] = df['departure_time'].dt.to_period('M')
            else:
                df['period'] = df['departure_time'].dt.date
            
            # Aggregate data
            aggregated = df.groupby('period').agg({
                'flight_number': 'count',
                'airline': 'nunique',
                'origin': 'nunique',
                'destination': 'nunique'
            }).to_dict('index')
            
            # Convert period keys to strings for JSON serialization
            result = {}
            for period_key, data in aggregated.items():
                result[str(period_key)] = {
                    'flights': data['flight_number'],
                    'airlines': data['airline'],
                    'origins': data['origin'],
                    'destinations': data['destination']
                }
            
            return result
            
        except Exception as e:
            logger.error(f"Error aggregating by time period: {str(e)}")
            return {}
