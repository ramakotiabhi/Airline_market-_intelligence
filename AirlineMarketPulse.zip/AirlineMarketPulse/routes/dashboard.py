from flask import Blueprint, render_template, request, jsonify, current_app
import logging
from datetime import datetime, timedelta
from utils.helpers import filter_data_by_date, format_currency

logger = logging.getLogger(__name__)

dashboard_bp = Blueprint('dashboard', __name__, url_prefix='/dashboard')

@dashboard_bp.route('/')
def dashboard():
    """Main dashboard page"""
    return render_template('dashboard.html')

@dashboard_bp.route('/api/stats')
def get_dashboard_stats():
    """Get dashboard statistics"""
    try:
        flight_data = current_app.flight_data
        route_analysis = current_app.route_analysis
        
        # Calculate basic statistics
        total_flights = len(flight_data)
        total_routes = len(route_analysis)
        
        # Get active airlines
        airlines = list(set([f.get('airline', 'Unknown') for f in flight_data if f.get('airline')]))
        
        # Get popular destinations
        destinations = {}
        for flight in flight_data:
            dest = flight.get('destination', 'Unknown')
            if dest != 'Unknown':
                destinations[dest] = destinations.get(dest, 0) + 1
        
        popular_destinations = sorted(destinations.items(), key=lambda x: x[1], reverse=True)[:10]
        
        # Get popular routes
        popular_routes = []
        for route, data in list(route_analysis.items())[:10]:
            popular_routes.append({
                'route': route,
                'frequency': data.get('frequency', 0),
                'origin': data.get('origin', ''),
                'destination': data.get('destination', '')
            })
        
        stats = {
            'total_flights': total_flights,
            'total_routes': total_routes,
            'active_airlines': len(airlines),
            'airlines': airlines,
            'popular_destinations': popular_destinations,
            'popular_routes': popular_routes,
            'last_updated': current_app.last_updated.isoformat() if current_app.last_updated else None
        }
        
        return jsonify(stats)
        
    except Exception as e:
        logger.error(f"Error getting dashboard stats: {str(e)}")
        return jsonify({'error': 'Failed to get dashboard statistics'}), 500

@dashboard_bp.route('/api/route-data')
def get_route_data():
    """Get route data for visualization"""
    try:
        route_analysis = current_app.route_analysis
        
        # Prepare data for charts
        route_data = []
        for route, data in route_analysis.items():
            route_data.append({
                'route': route,
                'origin': data.get('origin', ''),
                'destination': data.get('destination', ''),
                'frequency': data.get('frequency', 0),
                'average_price': data.get('average_price', 0),
                'peak_season': data.get('peak_season', 'Unknown'),
                'demand_trend': data.get('demand_trend', 'stable')
            })
        
        # Sort by frequency
        route_data.sort(key=lambda x: x['frequency'], reverse=True)
        
        return jsonify({
            'routes': route_data[:20],  # Top 20 routes
            'total_routes': len(route_data)
        })
        
    except Exception as e:
        logger.error(f"Error getting route data: {str(e)}")
        return jsonify({'error': 'Failed to get route data'}), 500

@dashboard_bp.route('/api/price-trends')
def get_price_trends():
    """Get price trend data"""
    try:
        price_trends = current_app.price_trends
        
        # Prepare trend data for charts
        trend_data = []
        for route, trends in price_trends.items():
            if isinstance(trends, list):
                for trend in trends:
                    trend_data.append({
                        'route': route,
                        'date': trend.get('date', ''),
                        'price': trend.get('average_price', 0),
                        'min_price': trend.get('min_price', 0),
                        'max_price': trend.get('max_price', 0)
                    })
        
        return jsonify({
            'trends': trend_data,
            'total_trends': len(trend_data)
        })
        
    except Exception as e:
        logger.error(f"Error getting price trends: {str(e)}")
        return jsonify({'error': 'Failed to get price trends'}), 500

@dashboard_bp.route('/api/filter')
def filter_dashboard_data():
    """Filter dashboard data based on parameters"""
    try:
        # Get filter parameters
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        airline = request.args.get('airline')
        origin = request.args.get('origin')
        destination = request.args.get('destination')
        
        flight_data = current_app.flight_data
        
        # Apply filters
        filtered_data = flight_data
        
        if start_date and end_date:
            filtered_data = filter_data_by_date(filtered_data, start_date, end_date)
        
        if airline:
            filtered_data = [f for f in filtered_data if f.get('airline') == airline]
        
        if origin:
            filtered_data = [f for f in filtered_data if f.get('origin') == origin]
        
        if destination:
            filtered_data = [f for f in filtered_data if f.get('destination') == destination]
        
        # Calculate filtered statistics
        filtered_stats = {
            'total_flights': len(filtered_data),
            'flights': filtered_data[:100],  # Limit for performance
            'airlines': list(set([f.get('airline', 'Unknown') for f in filtered_data])),
            'routes': list(set([f"{f.get('origin', '')}-{f.get('destination', '')}" 
                               for f in filtered_data if f.get('origin') and f.get('destination')]))
        }
        
        return jsonify(filtered_stats)
        
    except Exception as e:
        logger.error(f"Error filtering dashboard data: {str(e)}")
        return jsonify({'error': 'Failed to filter data'}), 500

@dashboard_bp.route('/api/heatmap-data')
def get_heatmap_data():
    """Get data for demand heatmap visualization"""
    try:
        flight_data = current_app.flight_data
        
        # Create heatmap data based on city demand
        city_demand = {}
        
        for flight in flight_data:
            origin = flight.get('origin', 'Unknown')
            destination = flight.get('destination', 'Unknown')
            
            if origin != 'Unknown':
                city_demand[origin] = city_demand.get(origin, 0) + 1
            if destination != 'Unknown':
                city_demand[destination] = city_demand.get(destination, 0) + 1
        
        # Convert to heatmap format
        heatmap_data = []
        for city, demand in city_demand.items():
            heatmap_data.append({
                'city': city,
                'demand': demand,
                'intensity': min(demand / max(city_demand.values()) if city_demand.values() else 1, 1)
            })
        
        return jsonify({
            'heatmap': heatmap_data,
            'max_demand': max(city_demand.values()) if city_demand.values() else 0
        })
        
    except Exception as e:
        logger.error(f"Error getting heatmap data: {str(e)}")
        return jsonify({'error': 'Failed to get heatmap data'}), 500
