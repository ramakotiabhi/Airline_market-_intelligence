from flask import Blueprint, render_template, request, jsonify, current_app
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

insights_bp = Blueprint('insights', __name__, url_prefix='/insights')

@insights_bp.route('/')
def insights():
    """Main insights page"""
    return render_template('insights.html')

@insights_bp.route('/api/ai-insights')
def get_ai_insights():
    """Get AI-generated insights"""
    try:
        ai_insights = current_app.ai_insights
        
        if not ai_insights:
            return jsonify({
                'insights': [],
                'summary': 'No insights available yet. Data collection in progress.',
                'key_opportunities': []
            })
        
        return jsonify(ai_insights)
        
    except Exception as e:
        logger.error(f"Error getting AI insights: {str(e)}")
        return jsonify({'error': 'Failed to get AI insights'}), 500

@insights_bp.route('/api/business-recommendations')
def get_business_recommendations():
    """Get business recommendations for hostels"""
    try:
        ai_insights = current_app.ai_insights
        route_analysis = current_app.route_analysis
        
        recommendations = []
        
        # Extract recommendations from AI insights
        if ai_insights and 'insights' in ai_insights:
            for insight in ai_insights['insights']:
                if insight.get('business_impact') == 'high':
                    recommendations.append({
                        'title': insight.get('title', ''),
                        'description': insight.get('description', ''),
                        'recommendation': insight.get('recommendation', ''),
                        'category': insight.get('category', ''),
                        'confidence': insight.get('confidence', 0),
                        'priority': 'high'
                    })
        
        # Add route-based recommendations
        popular_routes = sorted(route_analysis.items(), 
                              key=lambda x: x[1].get('frequency', 0), 
                              reverse=True)[:5]
        
        for route, data in popular_routes:
            recommendations.append({
                'title': f"High Demand Route: {route}",
                'description': f"Route shows {data.get('frequency', 0)} flights with strong demand patterns.",
                'recommendation': f"Consider establishing hostel presence near {data.get('origin', '')} and {data.get('destination', '')} airports.",
                'category': 'Route Analysis',
                'confidence': 0.8,
                'priority': 'medium'
            })
        
        return jsonify({
            'recommendations': recommendations,
            'total_recommendations': len(recommendations)
        })
        
    except Exception as e:
        logger.error(f"Error getting business recommendations: {str(e)}")
        return jsonify({'error': 'Failed to get business recommendations'}), 500

@insights_bp.route('/api/market-analysis')
def get_market_analysis():
    """Get comprehensive market analysis"""
    try:
        flight_data = current_app.flight_data
        route_analysis = current_app.route_analysis
        ai_insights = current_app.ai_insights
        
        # Analyze market segments
        domestic_flights = [f for f in flight_data if f.get('origin') and f.get('destination')]
        
        # Airline market share
        airline_share = {}
        for flight in domestic_flights:
            airline = flight.get('airline', 'Unknown')
            airline_share[airline] = airline_share.get(airline, 0) + 1
        
        total_flights = len(domestic_flights)
        airline_market_share = {
            airline: (count / total_flights * 100) if total_flights > 0 else 0
            for airline, count in airline_share.items()
        }
        
        # Route performance analysis
        route_performance = []
        for route, data in list(route_analysis.items())[:10]:
            performance = {
                'route': route,
                'frequency': data.get('frequency', 0),
                'growth_potential': 'high' if data.get('frequency', 0) > 10 else 'medium',
                'seasonal_pattern': data.get('peak_season', 'Unknown'),
                'business_opportunity': data.get('frequency', 0) > 15
            }
            route_performance.append(performance)
        
        # Market trends
        market_trends = {
            'growth_routes': [r for r in route_performance if r['growth_potential'] == 'high'],
            'seasonal_peaks': list(set([r['seasonal_pattern'] for r in route_performance if r['seasonal_pattern'] != 'Unknown'])),
            'business_opportunities': len([r for r in route_performance if r['business_opportunity']])
        }
        
        analysis = {
            'airline_market_share': airline_market_share,
            'route_performance': route_performance,
            'market_trends': market_trends,
            'total_flights_analyzed': total_flights,
            'ai_summary': ai_insights.get('summary', 'Analysis in progress...') if ai_insights else 'Data collection in progress...'
        }
        
        return jsonify(analysis)
        
    except Exception as e:
        logger.error(f"Error getting market analysis: {str(e)}")
        return jsonify({'error': 'Failed to get market analysis'}), 500

@insights_bp.route('/api/seasonal-analysis')
def get_seasonal_analysis():
    """Get seasonal demand analysis"""
    try:
        flight_data = current_app.flight_data
        
        # Analyze seasonal patterns
        seasonal_data = {
            'summer': {'flights': 0, 'routes': set()},
            'winter': {'flights': 0, 'routes': set()},
            'spring': {'flights': 0, 'routes': set()},
            'autumn': {'flights': 0, 'routes': set()}
        }
        
        current_month = datetime.now().month
        
        # Categorize flights by season based on current data
        for flight in flight_data:
            route = f"{flight.get('origin', '')}-{flight.get('destination', '')}"
            
            # Simple seasonal categorization (could be enhanced with historical data)
            if current_month in [12, 1, 2]:  # Summer
                seasonal_data['summer']['flights'] += 1
                seasonal_data['summer']['routes'].add(route)
            elif current_month in [6, 7, 8]:  # Winter
                seasonal_data['winter']['flights'] += 1
                seasonal_data['winter']['routes'].add(route)
            elif current_month in [9, 10, 11]:  # Spring
                seasonal_data['spring']['flights'] += 1
                seasonal_data['spring']['routes'].add(route)
            else:  # Autumn
                seasonal_data['autumn']['flights'] += 1
                seasonal_data['autumn']['routes'].add(route)
        
        # Convert sets to lists for JSON serialization
        for season in seasonal_data:
            seasonal_data[season]['routes'] = list(seasonal_data[season]['routes'])
            seasonal_data[season]['unique_routes'] = len(seasonal_data[season]['routes'])
        
        return jsonify({
            'seasonal_patterns': seasonal_data,
            'current_season': 'summer' if current_month in [12, 1, 2] else 
                             'winter' if current_month in [6, 7, 8] else
                             'spring' if current_month in [9, 10, 11] else 'autumn',
            'analysis_date': datetime.now().isoformat()
        })
        
    except Exception as e:
        logger.error(f"Error getting seasonal analysis: {str(e)}")
        return jsonify({'error': 'Failed to get seasonal analysis'}), 500

@insights_bp.route('/api/route-insights/<route>')
def get_route_insights(route):
    """Get detailed insights for a specific route"""
    try:
        route_analysis = current_app.route_analysis
        flight_data = current_app.flight_data
        
        if route not in route_analysis:
            return jsonify({'error': 'Route not found'}), 404
        
        route_data = route_analysis[route]
        
        # Get flights for this route
        route_flights = [f for f in flight_data 
                        if f"{f.get('origin', '')}-{f.get('destination', '')}" == route]
        
        # Analyze route-specific data
        airlines_on_route = list(set([f.get('airline', 'Unknown') for f in route_flights]))
        
        insights = {
            'route': route,
            'basic_info': route_data,
            'airlines': airlines_on_route,
            'total_flights': len(route_flights),
            'flight_frequency': route_data.get('frequency', 0),
            'average_price': route_data.get('average_price', 0),
            'peak_season': route_data.get('peak_season', 'Unknown'),
            'demand_trend': route_data.get('demand_trend', 'stable'),
            'business_insights': {
                'market_position': 'high' if route_data.get('frequency', 0) > 15 else 'medium',
                'competition_level': 'high' if len(airlines_on_route) > 3 else 'medium',
                'hostel_opportunity': route_data.get('frequency', 0) > 10
            }
        }
        
        return jsonify(insights)
        
    except Exception as e:
        logger.error(f"Error getting route insights: {str(e)}")
        return jsonify({'error': 'Failed to get route insights'}), 500
