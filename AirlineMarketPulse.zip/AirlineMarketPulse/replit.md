# Australian Airline Market Intelligence

## Overview

This is a comprehensive Flask-based web application that provides airline market demand analysis and business intelligence for hostel operators across Australia. The application leverages real-time flight data collection, AI-powered analysis, and interactive visualizations to deliver strategic insights for business decision-making.

## System Architecture

### Backend Architecture
- **Flask Framework**: Main web application framework with Blueprint-based modular routing
- **In-Memory Data Storage**: MVP approach using application-level storage for flight data, route analysis, and AI insights
- **Background Processing**: APScheduler for automated data collection every 30 minutes
- **Microservices Pattern**: Separate services for data collection, AI analysis, and web scraping

### Frontend Architecture
- **Server-Side Rendering**: Jinja2 templates with Bootstrap 5 and Replit dark theme
- **Progressive Enhancement**: JavaScript for interactive features and real-time updates
- **Responsive Design**: Mobile-first approach using Bootstrap grid system
- **Component-Based Structure**: Modular JavaScript for charts, dashboard, and insights

## Key Components

### Data Collection Layer
- **DataCollector Service**: Integrates with OpenSky Network and AviationStack APIs
- **WebScraper Service**: Uses trafilatura and BeautifulSoup4 for airline website data extraction
- **Data Models**: Structured data classes for FlightData and RouteAnalysis

### AI Analysis Layer
- **AIAnalyzer Service**: OpenAI GPT-4o integration for generating business insights
- **Fallback System**: Mock insights when API is unavailable
- **Business Intelligence**: Tailored recommendations for hostel operators

### User Interface Layer
- **Dashboard Module**: Real-time metrics, charts, and data filtering
- **Insights Module**: AI-generated market analysis and business recommendations
- **Visualization Suite**: Chart.js and Plotly.js for interactive data presentation

### Data Processing Layer
- **DataProcessor Utility**: Pandas/NumPy for route analysis and statistical calculations
- **Helper Functions**: Date filtering, currency formatting, and distance calculations

## Data Flow

1. **Data Collection**: Scheduled background jobs collect flight data from external APIs
2. **Data Processing**: Raw data is normalized and analyzed using statistical methods
3. **AI Analysis**: Processed data is sent to OpenAI for business insight generation
4. **Data Storage**: Results are stored in application memory for quick access
5. **User Interface**: Dashboard and insights pages fetch data via API endpoints
6. **Visualization**: Charts and graphs are dynamically generated using JavaScript libraries

## External Dependencies

### APIs and Services
- **OpenSky Network**: Free tier flight tracking data
- **AviationStack**: Commercial airline data API (optional)
- **OpenAI API**: GPT-4o for AI-powered analysis
- **Web Scraping**: Airline websites for additional market data

### Frontend Libraries
- **Bootstrap 5**: UI framework with Replit dark theme
- **Chart.js**: Interactive charts and graphs
- **Plotly.js**: Advanced visualizations and maps
- **Font Awesome**: Icon library

### Python Dependencies
- **Flask**: Web framework
- **Pandas/NumPy**: Data processing
- **Requests**: HTTP client
- **BeautifulSoup4**: Web scraping
- **Trafilatura**: Text extraction
- **APScheduler**: Background job scheduling

## Deployment Strategy

### Current Setup
- **Development Environment**: Flask development server with debug mode
- **Port Configuration**: Runs on port 5000 with host 0.0.0.0
- **Environment Variables**: API keys and configuration via environment variables
- **Static Asset Serving**: Flask built-in static file serving

### Scaling Considerations
- **Database Migration**: Currently uses in-memory storage, ready for PostgreSQL integration
- **Caching Layer**: Can be enhanced with Redis for improved performance
- **Load Balancing**: Multiple Flask instances can be deployed behind a load balancer
- **Container Deployment**: Docker-ready structure for cloud deployment

## Changelog

```
Changelog:
- July 03, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```